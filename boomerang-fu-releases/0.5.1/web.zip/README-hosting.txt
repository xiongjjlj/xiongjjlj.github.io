Boomerang Fu browser port 0.5.1 — integration stable snapshot
Serve the entire directory over HTTP(S); use application/wasm for .wasm.
Frozen URL: https://boomerang-fu.arkevo.ai/releases/0.5.1/
Git tag: boomerang-fu-v0.5.1

Scope: local browser FFA kills, 2–6 keyboard/gamepad/bot slots, scoring,
round transitions, pause/rematch, base 36/31 maps at 2–4/5–6 players;
optional Base + DLC 57/52. ?map=levelN fixes one scene without rotation.
Controls: WASD/Space/J/K; second keyboard arrows/Enter/slash/Shift.
Click FIGHT to start; Esc pauses. Audio starts after user interaction.

Stable means frozen files and an integration baseline, not complete parity.
Teleportals, original UI, reflections/fog/other shaders and full audiovisual
and callback scheduling parity remain unfinished. No network multiplayer,
remote-agent control API, deterministic replay or score postMessage API.
Desktop Chromium + WebGL 2 is the validated browser; mobile is unvalidated.
Downloads use up to 4 attempts; inactivity 30s, each attempt <=300s.
After final failure, reload to retry. First load downloads large assets.
Keep Godot and FMOD notices with this build; preserve third-party rights.
